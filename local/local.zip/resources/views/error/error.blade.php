<!DOCTYPE html>
<html>
    <head>
        <title>
            Error
        </title>
        <?php include('local/resources/views/includes/referencias_top.html');?>
    </head>
    <body class="skin-black fixed">
        <!-- Site wrapper -->
        
        <div class="login-box text-center">
        <img src="local/resources/views/img/error.png" style="width: 250px;height: 250px;">
            <div class="login-logo" style="margin-bottom: 0px;">
                Algo ha salido mal!
            </div> 
             <a href="inicio"><strong>Regresar</strong></a>  
        </div>
        <!-- /.content-wrapper -->
        
        <!-- Control Sidebar -->
        <!-- ./wrapper -->
        <?php include('local/resources/views/includes/referencias_down.php');?>
    </body>
</html>
