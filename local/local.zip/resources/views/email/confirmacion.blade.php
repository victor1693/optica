<p>Hola estimado(a), {{$name}} a continuación le enviamos nuevamente su clave. Recuerde que la misma puede ser cambiada en el su panel de administración en: Configuración / Usuario / Seguridad.</p>
<p><strong>Muchas gracias!</strong></p>

<br>
<strong>Clave:</strong> {{$clave}}

 